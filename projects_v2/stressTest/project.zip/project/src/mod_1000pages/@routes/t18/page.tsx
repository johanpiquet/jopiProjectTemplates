export default function() {
    return <div>Stress Test 18</div>
};