export default function() {
    return <div>Stress Test 972</div>
};