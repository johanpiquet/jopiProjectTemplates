export default function() {
    return <div>Stress Test 967</div>
};