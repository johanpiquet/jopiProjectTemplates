export default function() {
    return <div>Stress Test 671</div>
};