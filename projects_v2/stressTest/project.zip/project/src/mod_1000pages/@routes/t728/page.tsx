export default function() {
    return <div>Stress Test 728</div>
};