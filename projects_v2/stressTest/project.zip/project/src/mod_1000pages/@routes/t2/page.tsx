export default function() {
    return <div>Stress Test 2</div>
};