export default function() {
    return <div>Stress Test 884</div>
};