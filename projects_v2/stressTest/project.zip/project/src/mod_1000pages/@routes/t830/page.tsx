export default function() {
    return <div>Stress Test 830</div>
};