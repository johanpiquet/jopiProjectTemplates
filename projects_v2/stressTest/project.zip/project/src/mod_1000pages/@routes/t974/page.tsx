export default function() {
    return <div>Stress Test 974</div>
};