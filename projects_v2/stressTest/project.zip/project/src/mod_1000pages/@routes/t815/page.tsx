export default function() {
    return <div>Stress Test 815</div>
};