export default function() {
    return <div>Stress Test 871</div>
};