export default function() {
    return <div>Stress Test 812</div>
};