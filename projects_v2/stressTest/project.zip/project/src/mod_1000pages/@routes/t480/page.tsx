export default function() {
    return <div>Stress Test 480</div>
};