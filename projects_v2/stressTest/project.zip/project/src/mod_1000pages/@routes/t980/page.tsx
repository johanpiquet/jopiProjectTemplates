export default function() {
    return <div>Stress Test 980</div>
};