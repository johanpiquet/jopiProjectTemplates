export default function() {
    return <div>Stress Test 745</div>
};