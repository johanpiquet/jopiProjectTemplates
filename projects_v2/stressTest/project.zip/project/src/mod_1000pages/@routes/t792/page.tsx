export default function() {
    return <div>Stress Test 792</div>
};