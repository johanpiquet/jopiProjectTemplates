export default function() {
    return <div>Stress Test 42</div>
};