export default function() {
    return <div>Stress Test 246</div>
};