export default function() {
    return <div>Stress Test 652</div>
};