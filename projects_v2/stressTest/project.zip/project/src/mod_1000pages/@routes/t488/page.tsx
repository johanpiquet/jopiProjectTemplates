export default function() {
    return <div>Stress Test 488</div>
};