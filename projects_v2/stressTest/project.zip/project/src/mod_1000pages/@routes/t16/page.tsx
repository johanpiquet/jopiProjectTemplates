export default function() {
    return <div>Stress Test 16</div>
};