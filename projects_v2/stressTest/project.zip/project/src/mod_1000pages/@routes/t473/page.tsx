export default function() {
    return <div>Stress Test 473</div>
};