export default function() {
    return <div>Stress Test 704</div>
};