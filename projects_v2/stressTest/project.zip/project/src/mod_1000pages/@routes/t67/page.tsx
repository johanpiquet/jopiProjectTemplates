export default function() {
    return <div>Stress Test 67</div>
};