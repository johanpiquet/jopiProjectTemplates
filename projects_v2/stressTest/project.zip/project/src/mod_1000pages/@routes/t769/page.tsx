export default function() {
    return <div>Stress Test 769</div>
};