export default function() {
    return <div>Stress Test 372</div>
};