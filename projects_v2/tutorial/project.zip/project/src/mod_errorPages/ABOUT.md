# About

This module declares the HTML template for the error pages.

This pages are returned when the request is a GET call and expected content is HTML. Which is typically the case when requesting a page from the browser.