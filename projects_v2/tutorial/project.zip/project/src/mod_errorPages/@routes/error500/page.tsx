import React from "react";

export default function() {
    return <div>
        My error 500 page
    </div>
}