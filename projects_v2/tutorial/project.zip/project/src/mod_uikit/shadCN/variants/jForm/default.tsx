import React from "react";
import { Checkbox } from "../../ui/checkbox";
import { Input } from "../../ui/input";
import {
    type JCheckboxFormFieldProps,
    type JFormVariants,
    type JTextFormFieldProps,
    type JFieldLabelProps,
    JFieldLabel, passThrough,
    type PassThrough_TextFormField, type PassThrough_NumberFormField,
    type PassThrough_CheckboxFormField,
    type PassThrough_FormMessage,
    type PassThrough_FileSelectField,
    useJFormField, type JFormMessageProps, type JFileSelectFieldProps
} from "jopijs/uikit";
import {cn} from "../../lib/utils";

function FieldLabel(p: JFieldLabelProps) {
    let clz = p.className;
    const isError = p.field.error;

    if (!clz) {
        let pt = passThrough(
            p.variants!.pt_FieldLabel,
            p.variants!.ptExtra_FieldLabel,
            isError ? p.variants!.ptError_FieldLabel : undefined,

            {
                title: isError ? "text-destructive" : undefined
            }
        );

        clz = pt.title;
    }

    return <label htmlFor={p.labelFor} className={clz}>{p.children}</label>;
}

function TextFormField(p: JTextFormFieldProps) {
    const field = useJFormField(p.name);

    let pt = passThrough<PassThrough_TextFormField>(
        p.variants!.pt_TextFormField,
        p.variants!.ptExtra_TextFormField,
        field.error ? p.variants!.ptError_TextFormField : undefined,

        {
            root: "grid gap-2",
            input: "",
            description: "",
            textContainer: "",
            errorMessage: "text-destructive",
            title: ""
        }
    );

    return <div className={pt.root}>
        {!!p.title && <JFieldLabel field={field} variants={p.variants} className={pt.title}>{p.title!}</JFieldLabel>}

        <Input id={p.id} className={pt.input} placeholder={p.placeholder}
               onChange={e => field.onChange(e.target.value)}
               value={field.value}
        />

        <div className={pt.textContainer}>
            <div className={pt.description}>{ p.description }</div>
            { field.error && <div className={pt.errorMessage}>{field.errorMessage}</div> }
        </div>
    </div>
}

function NumberFormField(p: JTextFormFieldProps) {
    const field = useJFormField(p.name);

    let pt = passThrough<PassThrough_NumberFormField>(
        p.variants!.pt_NumberFormField,
        p.variants!.ptExtra_NumberFormField,
        field.error ? p.variants!.ptError_NumberFormField : undefined,

        {
            root: "grid gap-2",
            input: "",
            description: "",
            textContainer: "",
            errorMessage: "text-destructive",
            title: ""
        }
    );

    return <div className={pt.root}>
        {!!p.title && <JFieldLabel field={field} variants={p.variants} className={pt.title}>{p.title!}</JFieldLabel>}

        <Input id={p.id} className={pt.input} placeholder={p.placeholder}
               onChange={e => field.onChange(e.target.value)}
               value={field.value}
        />

        <div className={pt.textContainer}>
            <div className={pt.description}>{ p.description }</div>
            { field.error && <div className={pt.errorMessage}>{field.errorMessage}</div> }
        </div>
    </div>
}

function CheckboxFormField(p: JCheckboxFormFieldProps) {
    const field = useJFormField(p.name);

    let pt = passThrough<PassThrough_CheckboxFormField>(
        p.variants!.pt_CheckboxFormField,
        p.variants!.ptExtra_CheckboxFormField,
        field.error ? p.variants!.ptError_CheckboxFormField : undefined,

        {
            root: "flex items-center gap-3",
            checkBox: "",
            textContainer: "grid gap-1.5 font-normal cursor-pointer",
            title: "text-sm leading-none font-medium",
            description: "text-muted-foreground text-sm",
            errorMessage: "text-destructive"
        }
    );

    return <div className={pt.root}>
        <Checkbox id={p.id} className={pt.checkBox}
                  defaultChecked={p.defaultChecked === true}
                  checked={field.value === true}
                  onCheckedChange={(checked) => {
                      field.onChange(checked === true)
                  }}
        />
        <div className={pt.textContainer} onClick={() => {field.onChange(!field.value)}}>
            <div className={pt.title}>{p.title}</div>
            {!!p.description && <p className={pt.description}>{p.description}</p>}
            {field.error && <div className={pt.errorMessage}>{field.errorMessage}</div>}
        </div>
    </div>
}

function FormMessage({message, ...p}: JFormMessageProps) {
    if (!message) return null;

    let text: React.ReactNode|undefined;
    let isConfirm: boolean = false;
    const v = p.variants!;

    if (message.isSubmitted) {
        isConfirm = true;

        // false means hiding the message.
        if (p.submittedMessage === false) return null;

        if (p.submittedMessage) text = p.submittedMessage;
        else if (v.textFormSubmitSuccess) text = v.textFormSubmitSuccess;
        else if (message.message) text = message.message;
        else text = "Form has been submitted";
    }
    else {
        if (message.isOk) return null;

        if (message.fieldErrors) {
            if (p.hideIfFieldErrors) return null;

            if (p.dataErrorMessage) text = p.dataErrorMessage;
            else if (v.textFormDataError) text = v.textFormDataError;
            else if (message.message) text = message.message;
            else text = "Some fields have errors";
        } else {
            if (p.errorMessage) text = p.errorMessage;
            else if (v.textFormSubmitError) text = v.textFormSubmitError;
            else if (message.message) text = message.message;
            else text = "An error occurred";
        }
    }

    let pt = passThrough<PassThrough_FormMessage>(
        isConfirm ? v.ptConfirm_FormMessage : v.ptError_FormMessage,
        isConfirm ? v.ptConfirmExtra_FormMessage : v.ptErrorExtra_FormMessage,
        undefined,

        isConfirm ? {
            root: "flex items-center justify-center",
            text: "max-w-3xl w-full p-2 bg-green-100 border border-green-500 rounded-lg shadow-lg text-center text-sm font-semibold text-green-800",
        } : {
            root: "flex items-center justify-center",
            text: "max-w-3xl w-full p-2 bg-red-100 border border-red-500 rounded-lg shadow-lg text-center text-sm font-semibold text-red-800",
        }
    );

    return <div className={pt.root}>
        <div className={pt.text}>{text}</div>
    </div>;
}

function FileSelectField(p: JFileSelectFieldProps) {
    const field = useJFormField(p.name);
    const fieldValue = field.value as File[];

    const [isDragOver, setIsDragOver] = React.useState(false);
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragOver(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragOver(false);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragOver(false);

        const files = e.dataTransfer.files;
        if (files.length > 0) field.onChange([...files]);
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) field.onChange([...files]);
    };

    const handleClick = () => {
        fileInputRef.current?.click();
    };

    const formatFileSize = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    let pt = passThrough<PassThrough_FileSelectField>(
        p.variants!.pt_FileSelectField,
        p.variants!.ptExtra_FileSelectField,
        field.error ? p.variants!.ptError_FileSelectField : undefined,

        {
            root: "w-full",

            dropZone: "relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors duration-200",
            dropZoneIfDragOver: "border-primary bg-primary/5",
            dropZoneIfNotDragOver: "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/50",

            dropZoneIcon: "w-12 h-12 rounded-full bg-muted flex items-center justify-center",
            dropZoneIconSvg: "w-6 h-6 text-muted-foreground",
            dropZoneTitle: "text-lg font-medium",
            dropZoneSubTitle: "text-sm text-muted-foreground mt-1",

            errorMessage: "mt-2 text-destructive text-sm",

            filePreviewRoot: "mt-4 p-4 bg-muted/50 rounded-lg border flex items-center justify-between",
            filePreviewIcon: "w-8 h-8 rounded bg-primary/10 flex items-center justify-center",
            filePreviewIconSvg: "w-4 h-4 text-primary",

            fileTitle: "font-medium text-sm pr-5 pl-5",
            fileSize: "text-xs text-muted-foreground pr-5 pl-5",

            fileRemove: "p-1 hover:bg-destructive/10 rounded transition-colors",
            fileRemoveSvg: "w-4 h-4 text-destructive"
        }
    );

    const textFileSelectFieldTitle = p.variants!.textFileSelectFieldTitle || "Click to select a file"
    const textFileSelectFieldDragging = p.variants!.textFileSelectFieldDragging || "Drop your file here"
    const textFileSelectFieldSubTitle = p.variants!.textFileSelectFieldSubTitle || "or drag-drop a file here"

    return (
        <div className={pt.root}>
            <input
                name={field.name}
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                className="hidden"
                accept={field.acceptFileType || "*/*"}
            />

            <div
                onClick={handleClick}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={cn(pt.dropZone, isDragOver ? pt.dropZoneIfDragOver : pt.dropZoneIfNotDragOver)}
            >
                <div className="flex flex-col items-center justify-center space-y-4">
                    <div className={pt.dropZoneIcon}>
                        <svg
                            className={pt.dropZoneIconSvg}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                            />
                        </svg>
                    </div>

                    <div>
                        <p className={pt.dropZoneTitle}>
                            {isDragOver ? textFileSelectFieldDragging : textFileSelectFieldTitle}
                        </p>
                        <p className={pt.dropZoneSubTitle}>
                            {textFileSelectFieldSubTitle}
                        </p>
                    </div>
                </div>
            </div>

            {field.errorMessage && (
                <div className={pt.errorMessage}>{field.errorMessage}</div>
            )}

            {fieldValue && (
                <div className={pt.filePreviewRoot}>
                    <div className="flex items-center space-x-3">
                        <div className={pt.filePreviewIcon}>
                            <svg
                                className={pt.filePreviewIconSvg}
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                />
                            </svg>
                        </div>
                        <div>
                            <p className={pt.fileTitle}>{fieldValue[0].name}</p>
                            <p className={pt.fileSize}>{formatFileSize(fieldValue[0].size)}</p>
                        </div>
                    </div>

                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            field.onChange(undefined);
                        }}
                        className={pt.fileRemove}
                    >
                        <svg
                            className={pt.fileRemoveSvg}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
            )}
        </div>
    );
}

const defaultFormVariant: JFormVariants = {
    FieldLabel,
    TextFormField,
    CheckboxFormField,
    NumberFormField,
    FormMessage,
    FileSelectField
}

export default function createFormVariants(extendWith?: Partial<JFormVariants>): JFormVariants {
    if (!extendWith) return defaultFormVariant;
    return {...defaultFormVariant, ...extendWith};
}