import D from "./en-us.ts";
export default D;