interface I0 {
    name: string|number;
    forename: string|number;
}

function fs_0(data: I0): string {return "Hello " + data.name + " " + data.forename + "!"}

export const lang = "en-us";

export default {
    invalidIdentifierOrPassword() { return "Invalid identifier" },
    checkMailOrPassword() { return "Check you e-mail and/or password" },
    rememberMe() { return "Remember me" },
    forgotPassword() { return "Forgot password?" },
    welcomeBack() { return "Welcome back! Please sign in to continue" },
    signIn() { return "Sign in" },
    nameForename(data: I0) { return fs_0(data); },
}