import L1 from "./en-us.ts";
import defaultLang from "./default.ts";

const byLang = {
    "en-us": L1,
};

export default function get(lang: string) { return ((byLang as any)[lang]) || defaultLang }