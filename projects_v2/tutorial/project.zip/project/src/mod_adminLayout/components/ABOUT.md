# About

This directory is not part of Jopi.

Here we have put our local not-shared React components.