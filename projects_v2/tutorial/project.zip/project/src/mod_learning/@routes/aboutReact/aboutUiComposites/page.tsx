// We import our composite.
// If you have an error, then start your app in dev mode.
// This will update the internal generated code (_jopiLinkerGen dir)
//
import Comp1 from "@/uiComposites/comp1";

export default function () {
    //Is equivalent to <><A1/><A2/></>
    return <Comp1 />
}

// URL: http://localhost:3000/aboutReact/aboutUiComposites