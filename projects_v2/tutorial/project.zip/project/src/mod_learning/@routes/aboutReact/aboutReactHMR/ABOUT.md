# About

React HMR allows updating your code and seeing the browser refresh instantly, while your React component state is restored.

In this demo an image is bouncing around the screen. When you change the text (see myText inside `page.tsx`)
then the text changes, but the image position is not reset, it continues to bounce in the same direction.