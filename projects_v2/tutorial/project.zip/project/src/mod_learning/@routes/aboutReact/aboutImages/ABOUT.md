# About

Here is a sample showing how to embed images into a page.

When importing an image, you don't have anything to do.  
Jopi automatically exposes the image.  
Also, it can choose to embed this image directly into the page HTML if it's small enough.