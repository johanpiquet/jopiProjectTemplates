# About

Jopi implements two dev mode:
- Server dev mode: which restarts the server on change and refreshes the browser.
- UI dev mode: which only refreshes the browser on change. But It's blazing fast!


Test url: http://localhost:3000/aboutReact/aboutDevMode
