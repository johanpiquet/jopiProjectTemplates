import {PageProps} from "jopijs/uikit";

// Import a CSS (or SCSS) file add this CSS to the page.
import "./style.scss";

// A simple demo component.
export default function(props: PageProps) {
    return <div>I'm a page using React.js for rendering</div>
}