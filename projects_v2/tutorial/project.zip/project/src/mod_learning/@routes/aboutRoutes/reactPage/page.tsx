// Import a css (or scss) file add this CSS to the page.
import "./style.scss";

// A simple demo component.
export default function() {
    return <div>I'm a page using React.js for rendering</div>
}