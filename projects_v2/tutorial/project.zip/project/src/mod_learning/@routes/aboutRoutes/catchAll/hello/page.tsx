import {PageProps} from "jopijs/uikit";

// http://localhost:3000/aboutRoutes/catchAll/hello
export default function(props: PageProps) {
    return <div>Hello!</div>
}