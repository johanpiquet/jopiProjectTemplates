// http://localhost:3000/aboutRoutes/catchAll/hello
export default function() {
    return <div>Hello!</div>
}