export default async function() {
    return new Response("hello world", {status: 200});
}