export default function() {
    return <div>Hello World from React!</div>;
}