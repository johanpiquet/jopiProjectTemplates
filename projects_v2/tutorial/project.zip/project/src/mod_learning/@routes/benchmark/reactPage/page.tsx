import {PageProps} from "jopijs/uikit";

export default function(props: PageProps) {
    return <div>Hello World from React!</div>;
}