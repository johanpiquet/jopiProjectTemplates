# About

This directory exposes some benchmarks.

* `getCall` folder: allows benchmarking a simple GET call and measure the internal rapidity.
* `reactPage` folder: allows benchmarking a React page rendering.

