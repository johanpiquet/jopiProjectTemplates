export default function(data: any) {
    console.log("card.product.added - startAnimation", data);
}