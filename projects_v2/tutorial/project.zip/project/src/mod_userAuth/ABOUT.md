# About

This module allows:
- Enabling user authentification with JWT (Json Web Token).
- Exposing a route for user login: http://localhost:3000/login
- Declaring some sample users (see file `myUsers.json`)
