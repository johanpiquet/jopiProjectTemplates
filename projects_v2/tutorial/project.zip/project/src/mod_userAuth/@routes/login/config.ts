import {RouteConfig} from "jopijs";

export default function(ctx: RouteConfig) {
}