import { Loader2 } from "lucide-react";
import { cn } from "../lib/utils"

interface SpinnerProps extends React.HTMLAttributes<HTMLDivElement> {
    size?: number | string;
}

const Spinner = ({ className, size = 24, ...props }: SpinnerProps) => {
    // @ts-ignore
    return <Loader2 className={cn("animate-spin", className)} size={size}{...props} />;
};

export {Spinner};