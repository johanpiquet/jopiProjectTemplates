// noinspection JSUnusedGlobalSymbols

import * as React from "react";
import {type CellContext, flexRender} from "@tanstack/react-table";

import {Table, TableBody, TableCell, TableHead, TableHeader, TableRow} from "../../ui/table";
import {Spinner} from "../../ui/spinner";
import {Button} from "../../ui/button";
import {type JActionItem, type JActionsProvider, type JTableVariants} from "jopijs/uikit";

import {ArrowUpDown, ChevronDown, MoreHorizontal} from "lucide-react";
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
    DropdownMenuTrigger
} from "../../ui/dropdown-menu";

import {Input} from "../../ui/input";
import {Checkbox} from "../../ui/checkbox";
import {formatNumber, type ScNumber} from "jopi-toolkit/jk_schema";

const defaultTableVariants: JTableVariants = {
    selectRowWidth: 60,
    actionRowWidth: 60,

    loadingScreenText: "Loading data",

    loadingScreenRenderer({text}: {text: React.ReactNode}) {
        return <div className="absolute inset-0 z-10 flex gap-6 items-center justify-center bg-background/90">
            <div className="font-semibold text-2xl text-center">{text}</div>
            <Spinner />
        </div>
    },

    tableRenderer(p) {
        const cpnTableHeader = <TableHeader>
            {p.table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                        const canResize = header.getContext().column.getCanResize();

                        let style: any = undefined;
                        if (canResize) style = {position: "relative", width: header.getSize()}

                        return (
                            <TableHead key={header.id} style={style}>
                                {header.isPlaceholder
                                    ? null
                                    : flexRender(
                                        header.column.columnDef.header,
                                        header.getContext()
                                    )}
                            </TableHead>
                        )
                    })}
                </TableRow>
            ))}
        </TableHeader>;

        const cpnTableBody = <TableBody>
            {p.table.getRowModel().rows?.length ? (
                p.table.getRowModel().rows.map((row) => (
                    <TableRow
                        key={row.id}
                        data-state={row.getIsSelected() && "selected"}
                    >
                        {row.getVisibleCells().map((cell) => (
                            <TableCell key={cell.id}>
                                {flexRender(
                                    cell.column.columnDef.cell,
                                    cell.getContext()
                                )}
                            </TableCell>
                        ))}
                    </TableRow>
                ))
            ) : (
                <TableRow>
                    <TableCell
                        colSpan={p.table.getAllColumns().length}
                        className="h-24 text-center"
                    >
                        {p.ifNoContent}
                    </TableCell>
                </TableRow>
            )}
        </TableBody>;

        return <Table>{cpnTableHeader}{cpnTableBody}</Table>;
    },

    createActionCell(actions: JActionsProvider) {
        return (r) => {
            const data = r.row.original;
            const items = actions(data);

            const menuItems = items?.map((i: JActionItem, offset) => {
                if (i.separator) {
                    return <DropdownMenuSeparator key={`sep-${offset}`} />;
                }

                return <DropdownMenuItem key={`sep-${offset}`} onClick={()=> i.onClick?.(data)}>{i.title}</DropdownMenuItem>
            });

            return (
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">{menuItems}</DropdownMenuContent>
                </DropdownMenu>
            )
        }
    },

    columnHeaderRenderer(p) {
        if (!p.canSort) {
            return p.title;
        }

        let clzWrp = "flex";
        let clz = "capitalize flex gap-2";

        if (p.canSort) clz += " cursor-pointer"

        if (p.field.onTableRendering?.headerCssClass) {
            clz += " " + p.field.onTableRendering?.headerCssClass;
        }

        const textAlign = p.field.onTableRendering?.textAlign;
        const arrow = <ArrowUpDown size={14} className="text-gray-400" />;

        if (textAlign == "center") {
            clzWrp += " justify-center";
        }
        else if (textAlign == "right") {
            clzWrp += " justify-end";
            clz += "  flex-row-reverse"
        }

        return ({ column }) => {
            const onClick = () => column.toggleSorting(column.getIsSorted() === "asc");
            const mustShowSort = column.getIsSorted() !== false;

            return <div className={clzWrp}>
                {
                    mustShowSort ?
                        <Button variant="ghost" className={clz} onClick={onClick}>{p.title} {arrow}</Button> :
                        <Button variant="ghost" className={clz} onClick={onClick}>{p.title}</Button>
                }
            </div>
        };
    },

    selectRowsHeaderRenderer() {
        return ({table}) => <div className="text-center">
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
            />
        </div>;
    },

    //region Cells rendering

    wrapCellValue(p) {
        let rules = p.field.onTableRendering;
        if (!rules) rules = {};

        let cssClasses = rules.cellCssClass || "";
        cssClasses += " px-4 py-1";

        if (rules) {
            switch (rules.textAlign) {
                case "left":
                    cssClasses += " text-left";
                    break;
                case "right":
                    cssClasses += " text-right";
                    break;
                case "center":
                    cssClasses += " text-center";
                    break;
            }
        }

        return (v) => <div className={cssClasses}>{v}</div>
    },

    selectRowsCellRenderer() {
        return ({row}) => <div className="text-center">
            <Checkbox
                checked={row.getIsSelected()}
                onCheckedChange={(value) => row.toggleSelected(!!value)}
                aria-label="Select row"
            />
        </div>;
    },

    cellRenderer_number(p) {
        const wrap = p.variants.wrapCellValue(p);

        return ({ cell }: CellContext<any, any>) => {
            return wrap(cell.getValue<string>());
        }
    },

    cellRenderer_decimal(p) {
        let defaultLocalFormat = p.builderParams.defaultLocal || "en-US";
        const fieldNumber = p.field as ScNumber;
        const wrap = p.variants.wrapCellValue(p);

        return ({ cell }: CellContext<any, any>) => {
            let value = cell.getValue<string>();
            return wrap(formatNumber(value, fieldNumber, defaultLocalFormat));
        }
    },

    cellRenderer_percent(p) {
        let defaultLocalFormat = p.builderParams.defaultLocal || "en-US";
        const fieldNumber = p.field as ScNumber;
        const wrap = p.variants.wrapCellValue(p);

        return ({ cell }: CellContext<any, any>) => {
            let value = cell.getValue<string>();
            return wrap(formatNumber(value, fieldNumber, defaultLocalFormat));
        }
    },

    cellRenderer_currency(p) {
        let defaultLocalFormat = p.builderParams.defaultLocal || "en-US";
        let defaultCurrency = p.builderParams.defaultCurrency || "USD";
        const fieldNumber = p.field as ScNumber;

        const wrap = p.variants.wrapCellValue(p);

        return ({ cell }: CellContext<any, any>) => {
            let value = cell.getValue<string>();
            return wrap(formatNumber(value, fieldNumber, defaultLocalFormat, defaultCurrency));
        }
    },

    cellRenderer(p) {
        const wrap = p.variants.wrapCellValue(p);

        return ({ cell }: CellContext<any, any>) => {
            return wrap(cell.getValue<string>());
        }
    },

    //endregion

    //region UI components renderers

    columnsSelectorRenderer(params) {
        return <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto">
                    Columns <ChevronDown />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                {params.table
                    .getAllColumns()
                    .filter((column) => column.getCanHide())
                    .map((column) => {
                        return (
                            <DropdownMenuCheckboxItem
                                key={column.id}
                                className="capitalize"
                                checked={column.getIsVisible()}
                                onCheckedChange={(value) => column.toggleVisibility(value) }
                            >
                                {column.id}
                            </DropdownMenuCheckboxItem>
                        )
                    })}
            </DropdownMenuContent>
        </DropdownMenu>;
    },

    statisticsRenderer(params) {
        return <div className="text-muted-foreground flex-1 text-sm">
            {params.table.getFilteredSelectedRowModel().rows.length} of{" "}
            {params.table.getFilteredRowModel().rows.length} row(s) selected.
        </div>;
    },

    filterRenderer(p) {
        return <Input
            placeholder={p.placeholder || "Filter values..."}
            value={p.filter}
            onChange={(event) => p.setFilter(event.target.value)}
            className="max-w-sm"
        />
    },

    pageSelectorRenderer(params) {
        const pageCount = params.table.getPageCount();
        const pageIndex = params.table.getState().pagination.pageIndex;

        return <div className="space-x-2">
            <Button variant="ghost">{pageIndex+1}/{pageCount}</Button>

            <Button
                variant="outline"
                size="sm"
                onClick={() => params.table.previousPage()}
                disabled={!params.table.getCanPreviousPage()}
            >
                Previous
            </Button>
            <Button
                variant="outline"
                size="sm"
                onClick={() => params.table.nextPage()}
                disabled={!params.table.getCanNextPage()}
            >
                Next
            </Button>
        </div>
    },

    layoutRenderer(items) {
        const Loader = items.variants.loadingScreenRenderer;

        return <div className="relative w-full">
            {items.isLoadingData && <Loader text={items.variants.loadingScreenText} />}
            <div className="flex items-center py-4">{items.filter}{items.columnsSelector}</div>
            <div className="overflow-hidden rounded-md border">{items.table}</div>
            <div className="flex items-center justify-end space-x-2 py-4">
                {items.statistics}
                <div className="flex items-center justify-end space-x-2 py-4">
                    {items.isRefreshingData && <Spinner className="text-red-200" />}
                    {items.pageSelector}
                </div>
            </div>
        </div>
    }

    //endregion
};

export default function createTableVariants(extendWith?: Partial<JTableVariants>): JTableVariants {
    if (!extendWith) return defaultTableVariants;
    return {...defaultTableVariants, extendWith};
}
