# About

This directory is the root of our project source code.

These items are specific to a Jopi project:

```
|- _jopiLinkerGen/   < Contains generated source code (don't edit!)
|- index.tsx          < The application entry-point
```