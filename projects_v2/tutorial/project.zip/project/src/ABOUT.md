# About

This directory is the root of our project source code.

These items are specific to a Jopi project:

```
|- _jopiLinkerGen/   < Contains generated source code (don't edit!)
|- index.ts          < The application entry-point
|
|- mod_adminLayout   < The module containing the template 
|- mod_userAuth      < The module installing user login features
|- mod_uiKit         < Allows using Jopi UiKit
```