#!/usr/bin/env bash

# If you need pausing in order to launch
# a terminal and debug manually.
#
# sleep 1d

bun install
bun run start
