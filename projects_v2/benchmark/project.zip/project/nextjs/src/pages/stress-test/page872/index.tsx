export default function() {
    return <div>Page 872/1000</div>
};