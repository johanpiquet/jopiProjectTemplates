export default function() {
    return <div>Page 668/1000</div>
};