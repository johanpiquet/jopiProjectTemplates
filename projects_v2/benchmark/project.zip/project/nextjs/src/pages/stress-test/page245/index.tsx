export default function() {
    return <div>Page 245/1000</div>
};