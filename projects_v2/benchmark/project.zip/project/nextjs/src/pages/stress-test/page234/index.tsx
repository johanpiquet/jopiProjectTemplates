export default function() {
    return <div>Page 234/1000</div>
};