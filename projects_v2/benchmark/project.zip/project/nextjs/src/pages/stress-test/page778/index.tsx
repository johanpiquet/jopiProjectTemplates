export default function() {
    return <div>Page 778/1000</div>
};