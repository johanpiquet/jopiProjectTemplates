export default function() {
    return <div>Page 650/1000</div>
};