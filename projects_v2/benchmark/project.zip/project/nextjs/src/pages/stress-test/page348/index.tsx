export default function() {
    return <div>Page 348/1000</div>
};