export default function() {
    return <div>Page 242/1000</div>
};