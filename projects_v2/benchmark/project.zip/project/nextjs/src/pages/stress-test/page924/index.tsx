export default function() {
    return <div>Page 924/1000</div>
};