export default function() {
    return <div>Page 688/1000</div>
};