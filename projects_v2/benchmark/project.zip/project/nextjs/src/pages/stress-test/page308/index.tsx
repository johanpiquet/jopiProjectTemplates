export default function() {
    return <div>Page 308/1000</div>
};