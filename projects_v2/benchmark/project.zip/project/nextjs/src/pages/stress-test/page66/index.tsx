export default function() {
    return <div>Page 66/1000</div>
};