export default function() {
    return <div>Page 347/1000</div>
};