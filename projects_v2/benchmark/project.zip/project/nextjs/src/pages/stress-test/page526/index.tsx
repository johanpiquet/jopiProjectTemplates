export default function() {
    return <div>Page 526/1000</div>
};