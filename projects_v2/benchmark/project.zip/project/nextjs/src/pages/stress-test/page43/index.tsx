export default function() {
    return <div>Page 43/1000</div>
};