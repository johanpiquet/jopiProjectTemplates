export default function() {
    return <div>Page 752/1000</div>
};