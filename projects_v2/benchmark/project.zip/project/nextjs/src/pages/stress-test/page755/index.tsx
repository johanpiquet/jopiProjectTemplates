export default function() {
    return <div>Page 755/1000</div>
};