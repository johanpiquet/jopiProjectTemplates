export default function() {
    return <div>Page 527/1000</div>
};