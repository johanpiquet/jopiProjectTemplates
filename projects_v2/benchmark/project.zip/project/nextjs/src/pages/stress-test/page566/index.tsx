export default function() {
    return <div>Page 566/1000</div>
};