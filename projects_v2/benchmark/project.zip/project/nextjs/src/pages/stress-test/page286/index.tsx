export default function() {
    return <div>Page 286/1000</div>
};