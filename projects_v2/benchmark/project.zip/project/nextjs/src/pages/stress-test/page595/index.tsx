export default function() {
    return <div>Page 595/1000</div>
};