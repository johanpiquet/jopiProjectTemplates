export default function() {
    return <div>Page 189/1000</div>
};