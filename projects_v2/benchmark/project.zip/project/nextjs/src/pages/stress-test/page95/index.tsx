export default function() {
    return <div>Page 95/1000</div>
};