export default function() {
    return <div>Page 496/1000</div>
};