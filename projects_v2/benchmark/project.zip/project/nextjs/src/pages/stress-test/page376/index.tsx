export default function() {
    return <div>Page 376/1000</div>
};