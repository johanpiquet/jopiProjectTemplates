export default function() {
    return <div>Page 783/1000</div>
};