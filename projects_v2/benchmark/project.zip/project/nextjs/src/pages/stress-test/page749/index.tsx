export default function() {
    return <div>Page 749/1000</div>
};