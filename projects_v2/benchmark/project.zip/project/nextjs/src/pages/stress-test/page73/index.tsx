export default function() {
    return <div>Page 73/1000</div>
};