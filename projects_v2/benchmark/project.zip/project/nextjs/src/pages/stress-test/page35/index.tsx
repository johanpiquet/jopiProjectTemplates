export default function() {
    return <div>Page 35/1000</div>
};