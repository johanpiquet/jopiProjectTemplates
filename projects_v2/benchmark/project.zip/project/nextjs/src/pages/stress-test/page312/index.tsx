export default function() {
    return <div>Page 312/1000</div>
};