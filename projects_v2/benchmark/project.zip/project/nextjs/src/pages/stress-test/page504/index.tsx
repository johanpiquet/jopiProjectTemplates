export default function() {
    return <div>Page 504/1000</div>
};