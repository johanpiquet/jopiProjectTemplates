export default function() {
    return <div>Page 686/1000</div>
};