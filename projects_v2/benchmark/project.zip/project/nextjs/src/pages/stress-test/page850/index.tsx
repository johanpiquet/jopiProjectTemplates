export default function() {
    return <div>Page 850/1000</div>
};