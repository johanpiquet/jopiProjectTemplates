export default function() {
    return <div>Page 75/1000</div>
};