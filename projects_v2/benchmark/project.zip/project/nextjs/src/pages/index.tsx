export default function Page() {
    return <div className="text-blue-400">Next.js - Benchmark project</div>
}