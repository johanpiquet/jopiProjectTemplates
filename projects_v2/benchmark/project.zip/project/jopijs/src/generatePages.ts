import * as jk_fs from "jopi-toolkit/jk_fs";

const NEXT_JS = false;
const PAGE_COUNT = 1000;

const template = `export default function() {
    return <div>Page COUNT/${PAGE_COUNT}</div>
};`

async function start() {
    let basePath = "";

    if (NEXT_JS) {
        basePath = jk_fs.join("..", "nextjs");

        for (let i = 1; i < PAGE_COUNT; i++) {
            let filePath = jk_fs.resolve(basePath, `src/pages/stress-test/page${i}/index.tsx`);
            await jk_fs.writeTextToFile(filePath, template.replace("COUNT", i.toString()));
        }
    } else {
        for (let i = 1; i < PAGE_COUNT; i++) {
            let filePath = jk_fs.resolve(basePath, `src/mod_${PAGE_COUNT}/@routes/stress-test/pages/page${i}/page.tsx`);
            await jk_fs.writeTextToFile(filePath, template.replace("COUNT", i.toString()));
        }
    }
}

await start();