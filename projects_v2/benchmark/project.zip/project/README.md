# README

This project allows benchmarking Jopi.js vs Next.js in term of performances.

Three things can be benchmarked:
- A-Homepage: time to serve a page
- B-API: time to respond to a call.
- C-Building: time to build 1000 pages.

See the [_scores](_scores) folder for the results.