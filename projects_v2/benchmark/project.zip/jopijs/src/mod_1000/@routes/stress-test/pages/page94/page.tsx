export default function() {
    return <div>Page 94/1000</div>
};