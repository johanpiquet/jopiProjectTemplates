export default function() {
    return <div>Page 292/1000</div>
};