export default function() {
    return <div>Page 268/1000</div>
};