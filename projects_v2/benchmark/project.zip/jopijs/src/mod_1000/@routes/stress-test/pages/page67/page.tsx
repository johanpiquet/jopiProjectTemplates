export default function() {
    return <div>Page 67/1000</div>
};