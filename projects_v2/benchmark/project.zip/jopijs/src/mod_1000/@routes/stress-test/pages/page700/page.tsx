export default function() {
    return <div>Page 700/1000</div>
};