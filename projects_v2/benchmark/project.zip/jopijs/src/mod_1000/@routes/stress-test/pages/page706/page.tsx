export default function() {
    return <div>Page 706/1000</div>
};