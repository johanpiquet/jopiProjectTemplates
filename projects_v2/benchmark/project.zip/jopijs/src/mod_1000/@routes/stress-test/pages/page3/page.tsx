export default function() {
    return <div>Page 3/1000</div>
};