export default function() {
    return <div>Page 273/1000</div>
};