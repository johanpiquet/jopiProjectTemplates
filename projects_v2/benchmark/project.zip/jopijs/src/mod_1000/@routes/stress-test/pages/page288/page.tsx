export default function() {
    return <div>Page 288/1000</div>
};