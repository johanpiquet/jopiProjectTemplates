export default function() {
    return <div>Page 384/1000</div>
};