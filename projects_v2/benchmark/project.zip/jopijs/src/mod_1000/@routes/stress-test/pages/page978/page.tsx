export default function() {
    return <div>Page 978/1000</div>
};