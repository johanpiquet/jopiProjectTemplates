export default function() {
    return <div>Page 680/1000</div>
};