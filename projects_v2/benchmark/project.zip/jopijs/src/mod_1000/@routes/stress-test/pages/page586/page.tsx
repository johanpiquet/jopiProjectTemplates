export default function() {
    return <div>Page 586/1000</div>
};