export default function() {
    return <div>Page 722/1000</div>
};