export default function() {
    return <div>Page 675/1000</div>
};