export default function() {
    return <div>Page 10/1000</div>
};