export default function() {
    return <div>Page 127/1000</div>
};