export default function() {
    return <div>Page 340/1000</div>
};