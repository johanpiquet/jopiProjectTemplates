export default function() {
    return <div>Page 940/1000</div>
};