export default function() {
    return <div>Page 835/1000</div>
};