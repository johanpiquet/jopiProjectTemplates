export default function() {
    return <div>Page 976/1000</div>
};