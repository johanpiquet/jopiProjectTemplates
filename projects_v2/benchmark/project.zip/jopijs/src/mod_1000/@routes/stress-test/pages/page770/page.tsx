export default function() {
    return <div>Page 770/1000</div>
};