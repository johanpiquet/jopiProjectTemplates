export default function() {
    return <div>Page 925/1000</div>
};