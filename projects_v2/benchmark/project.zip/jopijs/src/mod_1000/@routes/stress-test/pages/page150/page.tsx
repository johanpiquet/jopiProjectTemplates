export default function() {
    return <div>Page 150/1000</div>
};