export default function() {
    return <div>Page 626/1000</div>
};