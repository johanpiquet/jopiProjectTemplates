export default function() {
    return <div>Page 534/1000</div>
};