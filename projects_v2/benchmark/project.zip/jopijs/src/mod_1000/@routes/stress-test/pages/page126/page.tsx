export default function() {
    return <div>Page 126/1000</div>
};