export default function() {
    return <div>Page 725/1000</div>
};