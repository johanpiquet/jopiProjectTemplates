export default function() {
    return <div>Page 267/1000</div>
};