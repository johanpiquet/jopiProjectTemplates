export default function() {
    return <div>Page 378/1000</div>
};