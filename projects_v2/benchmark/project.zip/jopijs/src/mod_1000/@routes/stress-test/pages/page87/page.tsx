export default function() {
    return <div>Page 87/1000</div>
};