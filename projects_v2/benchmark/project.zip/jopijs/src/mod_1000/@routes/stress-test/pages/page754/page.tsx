export default function() {
    return <div>Page 754/1000</div>
};