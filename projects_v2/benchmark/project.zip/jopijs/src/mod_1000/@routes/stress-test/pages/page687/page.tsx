export default function() {
    return <div>Page 687/1000</div>
};