export default function() {
    return <div>Page 4/1000</div>
};