export default function() {
    return <div>Page 556/1000</div>
};