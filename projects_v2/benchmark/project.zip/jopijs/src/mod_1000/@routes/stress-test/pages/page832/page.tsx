export default function() {
    return <div>Page 832/1000</div>
};