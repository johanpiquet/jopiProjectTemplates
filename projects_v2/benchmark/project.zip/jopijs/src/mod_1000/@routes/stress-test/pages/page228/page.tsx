export default function() {
    return <div>Page 228/1000</div>
};