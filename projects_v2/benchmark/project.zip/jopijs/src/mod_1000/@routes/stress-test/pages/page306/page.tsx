export default function() {
    return <div>Page 306/1000</div>
};