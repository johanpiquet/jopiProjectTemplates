export default function() {
    return <div>Page 632/1000</div>
};