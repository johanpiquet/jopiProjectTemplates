export default function() {
    return <div>Page 592/1000</div>
};