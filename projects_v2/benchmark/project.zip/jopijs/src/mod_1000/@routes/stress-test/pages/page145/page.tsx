export default function() {
    return <div>Page 145/1000</div>
};