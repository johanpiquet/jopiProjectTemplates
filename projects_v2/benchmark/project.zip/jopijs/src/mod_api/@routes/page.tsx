export default function Page() {
    return <div className="text-blue-400">Jopi.js - Benchmark project</div>
}