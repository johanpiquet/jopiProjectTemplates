import {JopiRequest} from "jopijs";

let count = 0;

export default function onGET(req: JopiRequest) {
    return req.res_jsonResponse({"counter": count++})
}