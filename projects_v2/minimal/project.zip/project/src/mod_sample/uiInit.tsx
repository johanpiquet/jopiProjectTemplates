import {UiKitModule} from "jopijs/uikit";

export default function(myModule: UiKitModule) {
}